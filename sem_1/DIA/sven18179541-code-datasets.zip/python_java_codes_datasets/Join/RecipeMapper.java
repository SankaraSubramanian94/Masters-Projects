import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class RecipeMapper extends Mapper <LongWritable, Text, LongWritable, Text>
 {
 private static final String fileTag = "RM~";
 private static final String DATA_SEPARATOR = ",";

 public void map(LongWritable key, Text value, Context context)  throws IOException, 
 InterruptedException {
 String values[] = value.toString().split(DATA_SEPARATOR);

 StringBuilder dataStringBuilder = new StringBuilder();

 for (int index = 0; index < values.length; index++) {

      if (index != 0) {
        dataStringBuilder.append(values[index].toString().trim() + DATA_SEPARATOR);

      } else {
        dataStringBuilder.append(fileTag);

      }

    }

    String dataString = dataStringBuilder.toString();

    if (dataString != null && dataString.length() > 1) {

      dataString = dataString.substring(0, dataString.length() - 1);

    }

    dataStringBuilder = null;
    

 context.write(new LongWritable(Long.parseLong(values[0])), new Text(dataString));
 }
 }

