import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import java.util.ArrayList;

public class ReduceJoinReducer extends Reducer <LongWritable, Text, Text, Text> {

    public static final String TAG_SEPARATOR = "~";

    private static final String DATA_SEPARATOR = ",";

    private static final Text EMPTY_TEXT = new Text("");
    
    private ArrayList<Text> Recipe = new ArrayList<Text>();
    private ArrayList<Text> Energy = new ArrayList<Text>();

    @Override
     public void reduce(LongWritable key, Iterable<Text> values, Reducer<LongWritable, Text, Text, Text>.Context context) throws IOException,
InterruptedException {

    Energy.clear();
    Recipe.clear();

    String value;

    String[] spllitedValues;

    String tag;

    for (Text txtValue : values) {

      value = txtValue.toString();

      spllitedValues = value.split(TAG_SEPARATOR);

      tag = spllitedValues[0];

      if (tag.equalsIgnoreCase("EM")){

        Energy.add(new Text(spllitedValues[1]));

      } else if (tag.equalsIgnoreCase("RM")){

        Recipe.add(new Text( spllitedValues[1]));
      }
}    
    
        if (!Energy.isEmpty() && !Recipe.isEmpty()){
            for(Text EnergyData: Energy){
                for(Text RecipeData: Recipe){
                    context.write(EnergyData, RecipeData);

                          }
                    }
                        }
            }   
    }
    
