import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.mapreduce.Reducer;

/**
 * Reducer used in computing Pearson correlation.
 * 
 *
 */
public class PearsonReducer extends Reducer<VariableIndexPairsWritable, VariableValuePairsWritable, VariableIndexPairsWritable, PearsonComputationWritable> {

	private static final Log _log = LogFactory.getLog(PearsonReducer.class);
	
	@Override
	public void reduce(VariableIndexPairsWritable key, Iterable<VariableValuePairsWritable> values, Context context) throws IOException, InterruptedException {
		double x = 0.0d;
		double y = 0.0d;
		double xx = 0.0d;
		double yy = 0.0d;
		double xy = 0.0d;
		double n = 0.0d;
		
		for(VariableValuePairsWritable pairs : values) {
			x += pairs.getI();
			y += pairs.getJ();
			xx += Math.pow(pairs.getI(), 2.0d);
			yy += Math.pow(pairs.getJ(), 2.0d);
			xy += (pairs.getI() * pairs.getJ());
			n += 1.0d;
		}
		
		PearsonComputationWritable pearson = new PearsonComputationWritable(x, y, xx, yy, xy, n);
		context.write(key, pearson);
		_log.debug(key.toString() + ", " + pearson.toString());
	}
}
