import java.util.Date;
import java.util.Formatter;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class PearsonJob extends Configured implements Tool {

	/**
	 * Main method.
	 * @param args
	 * @throws Exception
	 */
	public static void main(String[] args) throws Exception {
		int result = ToolRunner.run(new Configuration(), new PearsonJob(), args);
		System.exit(result);
	}

	@Override
	public int run(String[] args) throws Exception {
		if(args.length != 2) {
			System.err.println("usage: PearsonJob <input path>");
			ToolRunner.printGenericCommandUsage(System.err);
			return -1;
		}

		String inPath = args[0];
		Formatter formatter = new Formatter();
//        String outPath = "Out"
  //              + formatter.format("%1$tm%1$td%1$tH%1$tM%1$tS", new Date());
          String outPath = args[1];

        Configuration config = getConf();
//        config.setInt("mapred.line.input.format.linespermap", 100);
		Job job = new Job(config, "pairwise pearson correlation");
		job.setJarByClass(PearsonJob.class);
//		job.setNumReduceTasks(4);

		FileInputFormat.addInputPath(job, new Path(inPath));
		FileOutputFormat.setOutputPath(job, new Path(outPath));

		job.setMapperClass(VariablePairMapper.class);
		job.setReducerClass(PearsonReducer.class);

		job.setMapOutputKeyClass(VariableIndexPairsWritable.class);
		job.setMapOutputValueClass(VariableValuePairsWritable.class);

		job.setOutputKeyClass(VariableIndexPairsWritable.class);
		job.setOutputValueClass(PearsonComputationWritable.class);

		return job.waitForCompletion(true) ? 0 : 1;
	}

}
