import java.io.IOException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class VariablePairMapper extends
		Mapper<LongWritable, Text, VariableIndexPairsWritable, VariableValuePairsWritable> {

	private static final Log _log = LogFactory.getLog(VariablePairMapper.class);
	private static final String DELIM = ",";

	@Override
	public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
		String line = value.toString(); //_log.debug(line);
		String[] tokens_1 = line.split(DELIM); //_log.debug("tokens.length="+tokens.length);
                String   tokens_2 = (tokens_1[2]+ "," + tokens_1[6]);
                //System.out.println("String value is:" + tokens_2);
                String[] tokens = tokens_2.split(DELIM);
		double[] arr = toDouble(tokens); //_log.debug("arr.length="+arr.length);

		for(int i=0; i < arr.length; i++) {
			for(int j=i+1; j < arr.length; j++) {
				VariableIndexPairsWritable k2 = new VariableIndexPairsWritable(i, j);
				VariableValuePairsWritable v2 = new VariableValuePairsWritable(arr[i], arr[j]);
				context.write(k2, v2);
				_log.debug(k2.toString() + ", " + v2.toString());
			}
		}
	}

	public double[] toDouble(String[] tokens) {
		double[] arr = new double[tokens.length];
		for(int i=0; i < tokens.length; i++) {
			arr[i] = Double.parseDouble(tokens[i]);
		}
		return arr;
	}
}

