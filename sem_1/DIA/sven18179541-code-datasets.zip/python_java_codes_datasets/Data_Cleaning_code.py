# Energy Data Cleaning

import pandas as pd 

energyData = pd.read_csv("D:/Data_Intensive/Datasets/final_datasets/Supply, transformation and consumption of oil and petroleum products.tsv", sep ='\t')
energyData.head()
energyData.dtypes

energyData_melt = pd.melt(energyData, id_vars=['nrg_bal','siec','unit','country_code'], var_name ='year', value_name ='energy_val')

energyData_melt.info()
energyData_melt.head(10)

energyData_melt['flag']=energyData_melt.energy_val.str.contains(':')
energyData_melt.head(10)
energyData_melt.dtypes

energyData_melt_remove = energyData_melt[(energyData_melt['flag']==False)&(energyData_melt['energy_val']!= '0')]
import numpy as np

np.unique(energyData_melt_remove[['year']])
energyData_melt_remove.dtypes
energyData_melt_remove.info
del energyData_melt_remove['flag']
energyData_melt_remove = energyData_melt_remove.reset_index(drop=True)
energyData_melt_remove['year'] = energyData_melt_remove['year'].astype(int)

energyData_melt_remove = energyData_melt_remove[energyData_melt_remove['year'].between(2010,2017) & ~energyData_melt_remove['country_code'].isin(['EU28','EA19'])]

energyData_melt_remove['siec_num'] =energyData_melt_remove['siec'].map(lambda x: x.strip().replace("_","").replace("-","")).str.replace(r"[a-zA-z]",'').astype('int64')
energyData_melt_remove.head(20)
energyData_melt_remove.dtypes

energyData_melt_remove.to_csv("D:/Data_Intensive/Datasets/final_datasets/energy.csv", index=False)


energyData['siec_sum']=''
Sum = 0
for i in range(0,len(energyData['siec_num'])):
    x = energyData['siec_num'].loc[i]
    while(x > 0):
        Reminder = x % 10
        Sum = Sum + Reminder
        x = x //10
    energyData['siec_sum'].loc[i] = Sum
    Sum = 0
energyData.head(10)
energyData = energyData[~energyData['country_code'].isin(['AL','BA','GE','LI','MD','ME','MK','UA','XK'])]

energyDataFinal = pd.merge(energyData,CountryMapping, on='country_code', how='left')
del energyDataFinal['siec_num']
del energyDataFinal['country_code']
energyData.to_csv("D:/Data_Intensive/Cleaned_Dataset/energy_final.csv", index=False)

# Recipes Data Cleaning

import pandas as pd 
rawRecipes = pd.read_csv("D:/Data_Intensive/Datasets/final_datasets/RAW_recipes.csv")
rawRecipes.dtypes

rawRecipes['submitted']= pd.to_datetime(rawRecipes['submitted'])
rawRecipes['year'] = pd.DatetimeIndex(rawRecipes['submitted']).year
rawRecipes=rawRecipes[rawRecipes['year'].between(2010,2017)]
rawRecipes.head(10)
rawRecipes.to_csv("D:/Data_Intensive/Datasets/final_datasets/rawRecipes_new.csv", index=False)


## Check Inner Join

import pandas as pd 

energyData = pd.read_csv("D:/Data_Intensive/Cleaned_Dataset/Cleaned/Energy.csv")

recipesData = pd.read_csv("D:/Data_Intensive/Cleaned_Dataset/Cleaned/Recipes.csv")

mergeData = pd.merge(energyData, recipesData, on = 'key_column', how = 'inner')

mergeData.count()


# Read the output of the joined dataset
import pandas as pd 

energyData = pd.read_csv("D:/Data_Intensive/Cleaned_Dataset/Joined_dataset/part-r-00000.csv", header=None,\
                         names =["energy_code","units","energy_val","country","recipes","key_column","n_ingredients"])
                         
energyData_1 = energyData[["energy_val","n_ingredients"]]

# Pearson Correlation
pearsoncorr = energyData_1.corr(method = 'pearson')

import seaborn as sb

sb.heatmap(pearsoncorr, 
            xticklabels=pearsoncorr.columns,
            yticklabels=pearsoncorr.columns,
            cmap='RdBu_r',
            annot=True,
            linewidth=0.5)

# Remove Outliers Energy Dataset
import pandas as pd 

energyData = pd.read_csv("D:/Data_Intensive/Cleaned_Dataset/Cleaned/Energy.csv")

import seaborn as sns
sns.boxplot(x=energyData['energy_val'])

from scipy import stats
import numpy as np

z = np.abs(stats.zscore(energyData_o['energy_val']))
print(z)

z = np.abs(stats.zscore(energyData_o['energy_val']))
print(z)

Q1 = energyData.quantile(0.25)
Q3 = energyData.quantile(0.75)
IQR = Q3 - Q1

print(IQR)
energyData_o = energyData_o[(z < 3)]

energyData_o.shape

sns.boxplot(x=energyData_o['energy_val'])

energyData_o.to_csv("D:/Data_Intensive/Cleaned_Dataset/Cleaned/Energy_New.csv", index=None)

# Remove Outliers Recipe Dataset

import pandas as pd 

RecipeData = pd.read_csv("D:/Data_Intensive/Cleaned_Dataset/Cleaned/Recipes.csv")

import seaborn as sns
sns.boxplot(x=RecipeData['n_ingredients'])

z = np.abs(stats.zscore(RecipeData_o['n_ingredients']))
print(z)

Q1 = RecipeData_o.quantile(0.25)
Q3 = RecipeData_o.quantile(0.75)
IQR = Q3 - Q1
print(IQR)

RecipeData_o = RecipeData_o[(z < 3)]

RecipeData_o.shape

import seaborn as sns
sns.boxplot(x=RecipeData_o['n_ingredients'])

RecipeData_o.to_csv("D:/Data_Intensive/Cleaned_Dataset/Cleaned/Recipes_New.csv", index=None)